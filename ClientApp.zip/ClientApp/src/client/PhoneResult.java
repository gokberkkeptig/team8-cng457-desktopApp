//package client;
//
//public class PhoneResult {
//    private String model;
//    private String Ccreatedb;
//    private String CDesc;
//
//    public sresult(String T, String d, String c) {
//        this.Ccreatedby = T;
//        this.Denteredon = d;
//        this.CDesc = c;
//    }
//
//    public String getCcreatedby() {
//        return Ccreatedby;
//    }
//
//    public void setCreatedby(String T) {
//        Ccreatedby = T;
//    }
//
//    public String getDenteredon() {
//        return Denteredon;
//    }
//
//    public void setDenteredon(String d) {
//        Denteredon = d;
//    }
//
//    public String getCDesc() {
//        return CDesc;
//    }
//
//    public void setCDesc(String c) {
//        CDesc = c;
//    }
//}
//}
