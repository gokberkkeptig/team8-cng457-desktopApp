package jsonhandlers;

public class Comment {

    private String comment;
    private int rating;
}
